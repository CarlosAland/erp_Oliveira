<?php
class Funcao
{
    private $nome;


    public function getNome()
    {
        return $this->nome;
    }
    public function set($valor)
    {
        $this->nome = $valor;
    }
}
