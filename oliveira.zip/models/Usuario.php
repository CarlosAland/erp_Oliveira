<?php

class Usuario
{
    private $id;
    private $nome;
    private $nomecompleto;
    private $senha;
}
